from setuptools import find_packages, setup

setup(
    name='Mátrix függvénykönyvtár',
    packages=find_packages(include=['Mátrix függvénykönyvtár']),
    version='0.1.0',
    description='Függvénykönyvtár mátrixműveletekhez.',
    author='Szemereki Barna Balázs',
)