class Matrix:
    adat = []
    matrix_sor = 0
    matrix_oszlop = 0
    def __init__(self,lista):
        self.adat = lista
        self.matrix_sor = len(lista)
        if self.matrix_sor < 1:
            raise ValueError("A mátrix nem lehet 0 elemű.")
        self.matrix_oszlop = len(lista[0])
        for sor in lista:
            hosz = len(sor)
            if hosz != self.matrix_oszlop:
                raise ValueError("A mátrix minden sorának azonos hosszúnak kell lennie.")


    def __str__(self):
        return str(self.adat)


def beolvas(fajlnev):
    eredmeny = []
    with open(fajlnev,'rt',encoding="utf-8") as file:
        while True:
            line = file.readline()
            if not line:
                break
            line_list = line.rstrip().split(",")
            line_list_float = []
            for x in line_list:
                x_float = float(x)
                line_list_float.append(x_float)
            eredmeny.append(line_list_float)
    return Matrix(eredmeny)


def matrix_szorzas_szammal(matrixA, sz):
    eredmeny = []
    for sor in matrixA.adat:
        eredmeny_lista = []
        for elem in sor:
            eredmeny_lista.append(elem * sz)
        eredmeny.append(eredmeny_lista)
    return Matrix(eredmeny)


def matrix_kiiras_fajlba(matrixA):
    with open("eredmeny.txt","w",encoding="utf-8") as file:
        sorszam = 0
        ossz = len(matrixA.adat)
        for sor in matrixA.adat:
            elemszam = 0
            osszes = len(sor)
            for elem in sor:
                file.write(str(elem))
                if elemszam < osszes-1:
                    file.write(",")
                elemszam += 1
            if sorszam < ossz-1:
                file.write("\n")
            sorszam += 1
        

def matrix_osztasa(matrixA,sz):
    eredmeny = []
    for sor in matrixA.adat:
        eredmeny_sor = []
        for elem in sor:
            eredmeny_sor.append(elem/sz)
        eredmeny.append(eredmeny_sor)
    return Matrix(eredmeny)


def matrix_rangja(matrixA):
    rang = 0
    for i in range(len(matrixA.adat)-1):
        if matrixA.adat[i][i] == 0:
            print("Hiba: 0-val osztás történt.")
            return None
        faktor = matrixA.adat[i][i] #első sor normálva
        for elem in range(len(matrixA.adat[i])):
            matrixA.adat[i][elem] = matrixA.adat[i][elem] / faktor

        
        for k in range(i + 1, len(matrixA.adat)):
            faktor2 = matrixA.adat[k][i]
            for j, elem in enumerate(matrixA.adat[k]):
                matrixA.adat[k][j] = elem - faktor2 * matrixA.adat[i][j]

    for sor in matrixA.adat:
        for elem in sor:
            if elem != 0:
                rang += 1
                break           
    return rang


def matrix_osszeadas(matrixA, matrixB):
    eredmeny = []
    if matrixA.matrix_sor != matrixB.matrix_sor or matrixA.matrix_oszlop != matrixB.matrix_oszlop:
        raise ValueError("Csak ugyanakkora dimenziójú mátrixokat lehet összeadni egymással.")
    else:
        for x in range(len(matrixA.adat)):
            sor = []
            for y in range(len(matrixA.adat[0])):
                sor.append(matrixA.adat[x][y] + matrixB.adat[x][y])
            eredmeny.append(sor)
    return Matrix(eredmeny)


def matrix_kivonas(matrixA,matrixB):
    eredmeny = []
    if matrixA.n != matrixB.n or matrixA.m != matrixB.m:
        raise ValueError("Csak ugyanakkora dimenziójú mátrixokat lehet kivonni egymásból.")
    else:
        for x in range(len(matrixA.adat)):
            sor = []
            for y in range(len(matrixA.adat[0])):
                sor.append(matrixA.adat[x][y] - matrixB.adat[x][y])
            eredmeny.append(sor)
    return Matrix(eredmeny)


def matrix_szorzas_matrixszal(matrixA,matrixB):
    if matrixA.matrix_oszlop != matrixB.matrix_sor:
        raise ValueError("Az A mátrix oszlopainak száma nem egyezik meg a B mátrix sorainak számával.")
    eredmeny = []
    for sorA in range(len(matrixA.adat)):
        eredmeny_sor = []
        for oszlopB in range(len(matrixB.adat[0])):
            elem_ertek = 0
            for oszlopA in range(len(matrixA.adat[0])):
                elem_ertek += (matrixA.adat[sorA][oszlopA] * matrixB.adat[oszlopA][oszlopB])
            eredmeny_sor.append(elem_ertek)
        eredmeny.append(eredmeny_sor)
    return Matrix(eredmeny)



def matrix_determinansa(matrixA):
    if matrixA.matrix_sor != matrixA.matrix_oszlop:
        raise ValueError("Csak n*n es mátrixoknak van determinánsa.")
    if len(matrixA.adat[0]) == 1:
        return matrixA.adat[0][0]
    elif len(matrixA.adat) == 2:
        return matrixA.adat[0][0] * matrixA.adat[1][1] - matrixA.adat[0][1] * matrixA.adat[1][0]
    else:
        det = 0
        for i in range(len(matrixA.adat)):
            elojel = (-1) ** i
            almatrix = []
            for sor in matrixA.adat[1:]:
                almatrix.append(sor[:i] + sor[i + 1:])
            matrix = Matrix(almatrix)
            aldet = matrix_determinansa(matrix)
            det += elojel * matrixA.adat[0][i] * aldet
        return det


def matrix_transzponaltja(matrixA):
    sorok = matrixA.matrix_sor
    oszlopok = matrixA.matrix_oszlop
    
    
    transzponalt = []
    for i in range(oszlopok):
        transzponalt.append([0] * sorok)
    
    for i in range(sorok):
        for j in range(oszlopok):
            transzponalt[j][i] = matrixA.adat[i][j]
    
    
    return Matrix(transzponalt)


def matrix_Gauss_eliminacio(matrixA):
    for i in range(len(matrixA.adat)-1):
        if matrixA.adat[i][i] == 0:
            print("Hiba: 0-val osztás történt.")
            return None
        faktor = matrixA.adat[i][i] #első sor normálva
        for elem in range(len(matrixA.adat[i])):
            matrixA.adat[i][elem] = matrixA.adat[i][elem] / faktor

        
        for k in range(i+1, len(matrixA.adat)):
            faktor2 = matrixA.adat[k][i]
            for j, elem in enumerate(matrixA.adat[k]):
                matrixA.adat[k][j] = elem - faktor2 * matrixA.adat[i][j]

    return matrixA

   

def matrix_inverze(matrixA):
    det = matrix_determinansa(matrixA)
    if det == 0:
        return "A mátrixnak nem létezik inverze"
    
    sorok = matrixA.matrix_sor
    egysegmatrix = []
    for i in range(len(matrixA.adat)):
        sor = []
        for j in range(len(matrixA.adat)):
            if i == j:
                sor.append(1)
            else:
                sor.append(0)
        egysegmatrix.append(sor)

        
    for sor in range(sorok):
        matrixA.adat[sor] += egysegmatrix[sor]

    for sor in range(sorok):
        oszlop = sor
        oszto = matrixA.adat[sor][sor]

        for j in range(sorok*2):
            matrixA.adat[sor][j] /= oszto
        
            
        for i in range(sorok):
            if i != sor:
                szorzo = matrixA.adat[i][oszlop]
                for j in range(sorok*2):
                    matrixA.adat[i][j] -= szorzo * matrixA.adat[sor][j]
    inverz = []
    for sor in matrixA.adat:
        inverz.append(sor[sorok:])
    return Matrix(inverz)


